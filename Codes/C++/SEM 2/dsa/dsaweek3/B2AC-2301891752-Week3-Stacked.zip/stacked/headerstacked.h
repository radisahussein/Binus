#ifndef HEADER_HEADER_H
#define HEADER_HEADER_H
#include <assert.h>

using namespace std;


// Linked list node
class Node
{
    public:
    int data;
    Node* next;
};

//remove a node given index
Node* deleteNode(Node* head)
{
    if (head == NULL)
        return NULL;
    
    //Move head pointer to next node
    Node* temp = head;
    head = head->next;

    delete temp;
    return head;
}

//Get length of linkedlist
int size(Node* head)
{
    int count = 0;
    Node* current = head;
    while (current != NULL)
    {
        count++;
        current = current->next;
    }

    return count;
}

//Push node, given head and data int
void push(Node** head_ref, int new_data)
{
    //allocate node
    Node* new_node = new Node();

    //put in data
    new_node->data = new_data;

    //linking old list off the new node
    new_node->next = (*head_ref);

    //move head to point to the new node
    (*head_ref) = new_node;
}


//function to print data inside linkedlist
void printList(Node* head)
{
    while (head != NULL)
    {
        cout << head->data << " ";
        head = head->next;
    }
}

int getData(Node* head, int index)
{
    Node* current = head;

    int count = 0;
    while (current != NULL)
    {
        if(count == index)
        {
            return (current->data);
        }
        count++;
        current = current->next;
    }

    assert(0);
    
}

#endif